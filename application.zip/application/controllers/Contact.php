<?php

class Contact extends CI_Controller
{
	
	public function index(){
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST'){
           
            $fullname      = $this->input->post('name'); 
            $email         = $this->input->post('email');
	        $contact       = $this->input->post('contact'); 
            $message       = $this->input->post('message');
            $date          = $this->default_datetime_zone(); 

            $contactData   = array(  'name' => $fullname, 'email' => $email,'contact' => $contact, 'message' => $message,  'date'=> $date, 'update_date'=> $date ); 

            if($this->setting_model->contact($contactData) == true){
		        
		        $this->session->set_flashdata('msg', "Send Your Message Successfully");
		        redirect('contact' , 'refresh');           

		    }else{
		        
		        $this->session->set_flashdata('msg', "Your Message Not Send");
		        redirect('contact' , 'refresh'); 

		    }

        }else{
        
        $data['message'] = $this->session->userdata('msg');
        $this->load->view('contact/contact', $data); 

        } 
        
	}

    /*========CURRENT TIME zONE ==========*/ 
	public function default_datetime_zone($date=null){

      date_default_timezone_set("Asia/Kolkata");
      return $today_date=date("Y-m-d h:i:s");
    }

    /*========= FOR SUBSCRIBE USER ==========*/
    
    public function subscribe(){

	    if ($_SERVER['REQUEST_METHOD'] === 'POST'){
	        
	        $email         = $this->input->post('email');
	        $fullname      = $this->input->post('name');
	        $date          = $this->default_datetime_zone(); 
            $subscribeData = array(  'subscriber_email' => $email, 'subscriber_name' => $fullname,  'date'=> $date );

            if($this->setting_model->subscribe($subscribeData) == true){
		        
		        $this->session->set_flashdata('msg', "Subscribe");
		        redirect('contact/subscribe' , 'refresh');           

		    }else{
		        
		        $this->session->set_flashdata('msg', "Not Subscribe");
		        redirect('contact/subscribe' , 'refresh'); 

		    }

	    }else{

	    	echo "subscribe"; die;
        }

    }	

}