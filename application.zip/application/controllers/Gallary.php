<?php

class Gallary extends CI_Controller
{
	
	public function index(){
       
       $data['gallery'] = $this->gallery_model->getImages();  
       $this->load->view('gallary/gallery', $data);
       
	}
}