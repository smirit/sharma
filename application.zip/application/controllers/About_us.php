<?php

class About_us extends CI_Controller
{
	
	function index(){
        
        $this->load->view('about/about'); 
	}
}