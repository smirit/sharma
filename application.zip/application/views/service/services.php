<!DOCTYPE html>
<html lang="en">
<style type="text/css">
	@media screen and (max-width: 568px){
.w3ls-section {
    margin-top: 20px;
}}
</style>
<?php $this->load->view('common/head'); ?>

<body>
    <?php $this->load->view('common/header'); ?>  
	<!-- banner -->
	<div class="banner inner-banner">
		
		<?php $this->load->view('common/menu'); ?>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
	<!--services-->
<!--services-->
	<div class="w3ls-section services">
		<div class="container">
			<h2 class="h3-w3l">services</h2> 
			<div class="services-left">
				<h4 class="title">Rajnagar Mercantile Credit Co-operative Society Maryadit</h4>
				<h5>Help You Anytime.</h5>
				<!-- <p class="data">Enim nim pariatur cliche reprehen chardson ad sqderit ad sveprehed sectetur adipiscing elit iatur clic.</p>
				<div class="more">
					<a href="#" data-toggle="modal" data-target="#myModal"> Read More</a>
				</div> -->
			</div>
			<div class="services-right">
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-lock" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>Safe & Secure</h5>
						<!-- <p>Itaque earum rerum hic a sapiente delectus</p> -->
					</div>	
					<div class="clearfix"></div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-clock-o" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>Save Time</h5>
						<!-- <p>Itaque earum rerum hic a sapiente delectus</p> -->
					</div>	
					<div class="clearfix"></div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-gg" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Instant Account</h5>
						<!-- <p>Itaque earum rerum hic a sapiente delectus</p> -->
					</div>
					<div class="clearfix"></div>
				</div>	
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-credit-card-alt" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">	
						<h5>Instalment Facility</h5>
						<!-- <p>Itaque earum rerum hic a sapiente delectus</p> -->
					</div>	
					<div class="clearfix"> </div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-shopping-cart" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>Low Service Charge</h5>
						<!-- <p>Itaque earum rerum hic a sapiente delectus</p> -->
					</div>	
					<div class="clearfix"> </div>
				</div>
				<div class="services-grid">
					<div class="col-md-2 col-sm-2 col-xs-2 sr-icon">
						<span class="fa fa-shopping-cart" aria-hidden="true"></span>
					</div>	
					<div class="col-md-10 col-sm-10 col-xs-10 sr-txt">
						<h5>Online Entry</h5>
						<!-- <p>Itaque earum rerum hic a sapiente delectus</p> -->
					</div>	
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//services-->
	<div class="agileits_w3layouts-services-mid">
		<div class="col-md-5 services-mid-img">
		</div>
		<div class="col-md-5 services-mid-text">
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="w3ls-section">
		<div class="container">  
			<div class="services-w3ls-row agileits-w3layouts">
				<div class="col-md-3 col-sm-3 col-xs-6 services-grid agileits-w3layouts">
					<i class="fa fa-user-secret" aria-hidden="true"></i>
					<h5>Secure Online Banking</h5>
					<!-- <p>Sapiente delectus maiores itaque earum rerum hic tenetur a alias phasellus.</p> -->
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 services-grid agileits-w3layouts">
					<i class="fa fa-comments" aria-hidden="true"></i>
					<h5>Low Service Charge</h5>
					<!-- <p>Tenetur a sapiente itaque earum rerum hic delectus maiores alias phasellus.</p> -->
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 services-grid agileits-w3layouts">
					<i class="fa fa-gift" aria-hidden="true"></i>
					<h5>Save Time</h5>
					<!-- <p>Itaque earum rerum hic tenetur a sapiente delectus maiores alias phasellus.</p> -->
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6 services-grid agileits-w3layouts">
					<i class="fa fa-list-alt" aria-hidden="true"></i>
					<h5>Instant Account</h5>
					<!-- <p>Earum rerum hic tenetur a alias sapiente delectus maiores itaque phasellus.</p> -->
				</div> 
				<div class="clearfix"> </div>
			</div>  
		</div>
	</div>
	<!-- //services -->

	<!--//services-->
    <?php $this->load->view('common/footer'); ?>

</body>

</html>