
<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/header'); ?>  
	<!-- banner -->
	<div class="banner inner-banner">
		
		<?php $this->load->view('common/menu'); ?>
		<!-- banner-text -->
		<!-- banner -->
	</div>	
	<!-- contact -->
	<div class="w3ls-section contact">
		<div class="container"> 
			<div class="w3ls-title">
			    
			    <?php if(!empty($message)){ ?>
				    	
				    <div class="alert alert-dismissible alert-success">
					  <button type="button" class="close" data-dismiss="alert">&times;</button>
					  <a href="#" class="alert-link"><?php echo $message; ?></a>
					</div>
                    
                <?php } ?>

				<h2 class="h3-w3l">contact us</h2> 
			</div>  
			<div class="w3ls_map">
				
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14721.283169757271!2d75.8259129!3d22.716315!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x8285b565eec7edf8!2sRajnagar+Mercantile!5e0!3m2!1sen!2sin!4v1551440813793" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				
			</div>
			<div class="contact_wthreerow agileits-w3layouts">
				<div class="col-md-5 agileits_w3layouts_contact_gridl">
				    
				    <?php $info = $this->setting_model->getinfo(); ?> 
					<div class="agileits_mail_grid_right_grid">
						<h4>Contact Info</h4>
						<ul class="contact_info">
							
							<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i><?php if(!empty($info->address)){ echo $info->address; } ?></li>
							<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i><?php if(!empty($info->email)){ echo $info->email; } ?></li>
							<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>+91 <?php if(!empty($info->contact1)){ echo $info->contact1; } ?> , <?php if(!empty($info->contact2)){ echo $info->contact2; } ?></li>
						</ul>
					</div>
				</div>
				<div class="col-md-7 w3l_contact_form">
					<h4>Contact Form</h4> 
					<form action="<?php echo base_url(); ?>contact" method="post">
						<input type="text" name="name" placeholder="Name" required="">
						<input type="email" name="email" placeholder="Email" required="">
						<input type="text" name="contact" placeholder="Mobile Number" required="">
						<textarea name="message"  required=""></textarea>
						<input type="submit" value="Submit">
					</form>
				</div>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //contact --> 

    <?php $this->load->view('common/footer'); ?>

</body>
</html>