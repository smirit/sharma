<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/fancybox/dist/jquery.fancybox.min.css" />
<style type="text/css">
	video {
  width: 100%;
  height: 340px;
  padding: 8px;
}
video{ object-fit:fill;}
</style>
<?php $this->load->view('common/head'); ?>
<body>
    <?php $this->load->view('common/header'); ?>   
	<!-- banner -->
	<div class="banner inner-banner">
		<?php $this->load->view('common/menu'); ?>   
	</div>	
	<!-- banner -->
	<!-- gallery -->
	<div class="w3ls-section gallery">
		<div class="container">   
			<div class="w3ls-title">
				<h2 class="h3-w3l">Media</h2> 
			</div>
			<div>
			<video controls loop autoplay>
	          <source src="<?php echo base_url('');?>Assets/video/video.mp4" type="video/mp4">
	          <source src="<?php echo base_url('');?>Assets/video/video.ogg" type="video/ogg">
	        </video>
	        </div>
			<div class="gallery-grids-top">
				<div class="gallery-grids agileits-w3layouts">
					
					<?php foreach ($gallery as $images) { ?>
					
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img"> 
						<a data-fancybox="gallery" class="" href="<?php echo base_url(); ?>accountbanking/Assets/gallery/<?php echo $images->image_name; ?>"  data-title="">
							<img class="img-responsive img-thumbnail" src="<?php echo base_url(); ?>accountbanking/Assets/gallery/<?php echo $images->image_name; ?>" alt="" style="max-height: 190px;"/> 
							<div class="w3ls-overlay">
								<h4>Our Gallery</h4>
							</div> 
						</a> 
					</div>  

					<?php } ?>

					

						
					<!-- <div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img gallery-mdl hover ehover14">
						<a data-fancybox="gallery" href="<?php echo base_url(); ?>Assets/images/g1.jpg" data-lightbox="example-set" data-title="">
							<img class="img-responsive" src="<?php echo base_url(); ?>Assets/images/g1.jpg" alt=""/>
							<div class="w3ls-overlay">
								<h4>Our Gallery</h4>
							</div> 
						</a> 
					</div> -->
					<div class="clearfix"> </div>	
					
				</div> 
			</div> 
		</div>
	</div>
	<!-- //gallery -->     

    <?php $this->load->view('common/footer'); ?> 
    <script src="<?php echo base_url(); ?>Assets/fancybox/dist/jquery.fancybox.min.js"></script>
</body>

</html>