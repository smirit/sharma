<!--footer-->
<div class="agile-footer w3ls-section">
	<div class="container">
		<div class="col-md-7 list-footer">
		  <ul class="footer-nav">
				<li><a  href="<?php echo site_url(); ?>">Home</a></li>
				<li><a  href="<?php echo site_url(); ?>/about_us">About</a></li>
				<li><a  href="<?php echo site_url(); ?>/service">Services</a></li>
				<li><a  href="<?php echo site_url(); ?>/gallary">Gallery</a></li>
				<li><a  href="<?php echo site_url(); ?>/contact">Contact Us</a></li>
		  </ul>
		  <p>Vivamus sed porttitor felis. Pellentesque habitant morbi tristique senectus et netus et ctetur adipiscing elit. Cras rutrum iaculis</p>
		</div>
		<div class="col-md-5 agileinfo-sub">
			<h6>Click the link below to start the subscription service</h6>
			<a href="#" data-toggle="modal" data-target="#myModal1">subscribe</a>
		</div>
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
		<p>© 2019 Banking. All rights reserved | Design by <a href="">Rahul</a></p>
	</div>
<!--//footer-->	
<!-- modal-subscribe -->
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<img src="<?php echo base_url(); ?>Assets/images/flogo.png" alt="logo"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
					<p>E-Banking's email newsletter provides subscribers with helpful articles on important issues in the banking industry, as well as news about events and more! To sign up for the newsletter, fill the below form.</p>
					<form class=" wthree-subsribe" action="#" method="post"> 
						<input type="text" name="name" placeholder="Your Name" required="">
						<input type="email" name="email" placeholder="your Email" required="">
						<input type="submit" value="SignUp"> 
						<div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<script src="<?php echo base_url(); ?>Assets/js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="<?php echo base_url(); ?>Assets/js/move-top.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>Assets/js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){ $().UItoTop({ easingType: 'easeOutQuart' }); });
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
		<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.js"></script>