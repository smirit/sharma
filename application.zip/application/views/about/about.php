<!DOCTYPE html>
<html lang="en">
<style type="text/css">
	.h11{color: #fff;font-size: 80px;font-family: arial;}
	@media screen and (max-width: 991px){
.panel-group {
    margin: 1em 0px 40em!impo;
}}
</style>
<?php $this->load->view('common/head'); ?>

<body>
    
    <?php $this->load->view('common/header'); ?>
	<!-- banner -->
	<?php $this->load->view('common/menu'); ?>	
	<!-- about -->
	<div class=" w3ls-section" id="inner-about">
		<div class="container">
			<h3 class="h3-w3l">about us</h3>
			<!-- about bottom-->
			<div class="about-bottom">
				<div class="col-md-6 about-w3right">
					
				</div>
				<div class="col-md-6 about-w3left"> 
					<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
						<div class="panel panel-default">
							
							<div id="" class="" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
								<div class="panel-body panel_text">
									Rajnagar Mercantile Credit Co-operative Society Maryadit is a Depository institution that is typically locally owned and operate. It is Very Safe,Secure And Convenient Banking. Whether you are a student, homemaker, business owner, salaried employee or a senior citizen, an Rajnagar Mercantile Credit Co-operative Society Maryadit Savings Account is just what you need to manage your money more efficiently. Rajnagar mercantile Credit Co-operative Society Maryadit give you four types account. Saving Account, Fixed Saving Account, Fixed Deposit Account and Redundant Account. and Experience the comfort of instant account opening. and We’re here to help you when you need financial support.
								</div>
							</div>
						</div>
						
					
						
					</div> 
				</div> 
				<div class="clearfix"> </div>
			</div>		
		</div>	
			<!-- //about-bottom -->
	</div>
	<!-- //about -->
	<!-- //Awards-->
	<div class="awards-agileinfo  w3ls-section">
		<div class="awardsw3-agileits banner-agileinfo">
			<div class="container">
				<div class="w3ls_banner_bottom_grids">
					<div class="col-sm-3 col-xs-3 w3ls_about_guage">
						<h4>Accounts</h4>
						<h1 class="h11">00</h1>
						<!-- <canvas id="gauge1" width="200" height="100"></canvas> -->
					</div>
					<div class="col-sm-3 col-xs-3 w3ls_about_guage">
						<h4>Branches</h4>
						<h1 class="h11">00</h1>
						<!-- <canvas id="gauge2" width="200" height="100"></canvas> -->
					</div>
					<div class="col-sm-3 col-xs-3 w3ls_about_guage">
						<h4>Customers</h4>
						<h1 class="h11">00</h1>
						<!-- <canvas id="gauge3" width="200" height="100"></canvas> -->
					</div>
					<div class="col-sm-3 col-xs-3 w3ls_about_guage">
						<h4>Followers</h4>
						<h1 class="h11">00</h1>
						<!-- <canvas id="gauge4" width="200" height="100"></canvas> -->
					</div>
					<div class="clearfix"> </div>
				</div> 
			</div>
		</div>
		<script src="js/jquery.gauge.js"></script>
		<script>
			$(document).ready(function (){
				$("#gauge1").gauge(70,{color: "#ef3708",unit: " %",type: "halfcircle"});
				$("#gauge2").gauge(70, {color: "#5f48f9", unit: " %",type: "halfcircle"});
				$("#gauge3").gauge(75, {color: "#10b55d",unit: " %",type: "halfcircle"});
				$("#gauge4").gauge(90, {color: "#20c4da",unit: " %",type: "halfcircle"});
			});
		</script> 
	</div>
	<!-- //Awards-->
	<!-- about -->
	<div id="about" class="w3ls-section about"> 
		<div class="container"> 
			<div class="about-agileinfo"> 
				<div class="col-sm-3  about-grids about-grids2">
					<img src="<?php echo base_url(); ?>Assets/images/g1.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="col-sm-6 about-text">
					<h2>Rajnagar Mercantile Credit Co-operative Society Maryadit</h2>
					<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt lorem sed velit fermentum lobortis. Fusce eu semper lacus, eget placerat mauris. Sed lectus tellus feugiat porttitor nulla. Sed porta magna vitae nisl vulputate lacinia. </p> -->
				</div>
				<div class="col-sm-3 about-grids about-grids2 inner-about-g3">
					<img src="<?php echo base_url(); ?>Assets/images/g2.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="clearfix"> </div>
			</div>	 			
		</div>	 			
	</div>			
	<!-- //about -->  
	<!-- team -->
	<!-- <div id="team" class="w3ls-section team agileits">
		<div class="team-agileinfo">
			<div class="container">  
				<h3 class="h3-w3l">Our Team</h3>
				<div class="team-row agileits-w3layouts">
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="<?php echo base_url(); ?>Assets/images/t1.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Nathan</h4>
									<p>Managing Director</p>
								</div> 
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div> 
							</div>
						</div>
					</div>					
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="<?php echo base_url(); ?>Assets/images/t2.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Hoover</h4>
									<p>Human Resources</p>
								</div>
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="<?php echo base_url(); ?>Assets/images/t3.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>James</h4>
									<p>Chief Risk Officer</p>
								</div>
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="<?php echo base_url(); ?>Assets/images/t4.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Sturgill</h4>
									<p>Chief Financial Officer</p>
								</div>
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div> 
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div> -->
<!-- //team -->   

	
<?php $this->load->view('common/footer'); ?>

</body>


</html>