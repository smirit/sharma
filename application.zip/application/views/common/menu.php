		<div class="header-nav"><!-- header-thre	e --> 	
			<nav class="navbar navbar-default">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						Menu 
					</button> 
				</div>
				<!-- top-nav -->
				<?php $menu=$this->uri->segment(1);?>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a href="<?php echo base_url(); ?>" <?php if(!$menu){?>class="active"<?php } ?> >Home</a></li>
						<li><a href="<?php echo base_url(); ?>about_us" <?php if($menu=='about_us'){?> class="active scroll"<?php } else { ?> class="scroll" <?php } ?> >About</a></li>    
						<li><a href="<?php echo base_url(); ?>service" <?php if($menu=='service'){?> class="active scroll"<?php } else { ?> class="scroll" <?php } ?>>Services</a></li>    
						<li><a href="<?php echo base_url(); ?>gallary" <?php if($menu=='gallary'){?> class="active scroll"<?php } else { ?> class="scroll" <?php } ?>>Media</a></li>    
						<!-- <li><a href="icons.html" data-toggle="dropdown">Short Codes<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="icons.html">Icons</a></li>
								<li><a href="typography.html">Typograpghy</a></li>
							</ul>
						</li> -->	
						<li><a href="<?php echo base_url(); ?>index.php/contact" <?php if($menu=='contact'){?> class="active scroll"<?php } else { ?> class="scroll" <?php } ?>>Contact Us</a></li>
					</ul>  
					<div class="clearfix"> </div>	
				</div>
			</nav>    
		</div>