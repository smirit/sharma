<style type="text/css">
.sub{padding: 12px;}
</style>
<!--footer-->
<div class="agile-footer w3ls-section footer-bootom">
	<div class="container">
		<div class="col-md-6 list-footer">
		  <ul class="footer-nav">
				<li><a  href="<?php echo site_url(); ?>">Home</a></li>
				<li><a  href="<?php echo site_url(); ?>/about_us">About</a></li>
				<li><a  href="<?php echo site_url(); ?>/service">Services</a></li>
				<li><a  href="<?php echo site_url(); ?>/gallary">Media</a></li>
				<li><a  href="<?php echo site_url(); ?>/contact">Contact Us</a></li>
		  </ul>
		</div>
		<div class="col-md-5 agileinfo-sub">
			<!--<h6>Click the link below to start the subscription service</h6>-->
		</div>
		<div class="col-md-1 sub">
			<!--<a href="#" data-toggle="modal" data-target="#myModal1">subscribe</a>-->
		</div>
		<div class="clearfix"></div>
     </div>
</div>	 
<div class="w3_agile-copyright text-center">
		<p>© 2019 Banking. All rights reserved | Developed By <a href="">Impetrosys Software Solution PVT. LTD.</a></p>
</div>
<!--//footer-->	
<!-- modal-subscribe -->
	<div class="modal bnr-modal fade" id="myModal1" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">

					<img src="<?php echo base_url(); ?>Assets/pages/h_logo.png" alt="logo"/>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body modal-spa">
					<p>E-Banking's email newsletter provides subscribers with helpful articles on important issues in the banking industry, as well as news about events and more! To sign up for the newsletter, fill the below form.</p>
					<form class=" wthree-subsribe" action="<?php echo base_url(); ?>contact/subscribe" method="post"> 
						<input type="text" name="name" placeholder="Your Name." required="">
						<input type="email" name="email" placeholder="Your Email." required="">
						<input type="submit" value="Subscribe"> 
                        <div class="clearfix"></div>
					</form>
				</div> 
			</div>
		</div>
	</div>
	<script src="<?php echo base_url(); ?>Assets/js/SmoothScroll.min.js"></script>
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript" src="<?php echo base_url(); ?>Assets/js/move-top.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>Assets/js/easing.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){ $().UItoTop({ easingType: 'easeOutQuart' }); });
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
		<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.js"></script>