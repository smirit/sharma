<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="http://m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
	(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "http://vdo.ai/core/w3layouts/vdo.ai.js");
	</script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','http://www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
    <!-- header -->
	<div class="headerw3-agile"> 
		<div class="header-w3mdl"><!-- header-two --> 
			<div class="container" style="width:100%"> 
				<div class="agileits-logo navbar-left">
				    <img src="<?php echo base_url(); ?>Assets/pages/h_logo.png" />
					<!--<h1><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>Assets/images/header_logo.png" alt="logo"/>Rajnagar Mercantile</a></h1><br>-->
					<!--<i><small class="small1">Credit Co-operative Society Maryadit</small></i> -->
				</div>
				<?php $info = $this->setting_model->getinfo(); ?> 
				<div class="agileits-hdright nav navbar-nav" style="float:left;margin-left: 30%;" >
					<div class="header-w3top" style="float:left;margin-left: 70%;"><!-- header-top --> 
						<!--<ul class="w3l-nav-top">-->
						<!--	<li><i class="fa fa-phone"></i><span> +91 9039555569 , 9575241797</span><br><i class="fa fa-envelope-o"></i> <span>support@rajnagarmercantile.in </span></li>-->
						<!--	<li></li>-->
						<!--</ul>-->
						<!-- <img src="http://rajnagarmercantile.in/Assets/pages/h_center.png"> -->
						<div class="clearfix"> </div> 	 
					</div>
					 <div class="agile_social_banner">
						<ul class="agileits_social_list">
						    <li><i class="fa fa-phone"></i><span> +91 <?php if(!empty($info->contact1)){ echo $info->contact1; } ?> , <?php if(!empty($info->contact2)){ echo $info->contact2; } ?> </span><br>
						    <i class="fa fa-envelope-o"></i> <span><?php if(!empty($info->email)){ echo $info->email; } ?> </span></li><br>
							<li><?php if(!empty($info->address)){ echo $info->address; } ?></li>
						</ul>
					</div>  
                    
				</div>
				<div class="clearfix"> </div> 
				<marquee style="color:crimson;font-weight: bold" direction="scroll" >राज नगर मर्केंटाइल क्रेडिट को आपरेटिव सोसाइटी मर्यादित , पता : 73/D, एरोड्रम  Rd , राज नगर, इंदौर, मध्य प्रदेश 452001 ,मो. न.  : +91 <?php if(!empty($info->contact1)){ echo $info->contact1." , "; } ?> <?php if(!empty($info->contact2)){ echo $info->contact2; } ?> ,  <?php if(!empty($info->email)){ echo "इ मेल : ".$info->email; } ?></marquee> 
			</div>	
		</div>	
	</div>	
	<!-- //header -->