<?php


class Setting_model extends CI_Model
{
	
	function getinfo(){
        
        $Query = $this->db->get_where('rn_setting', array('id' => 1));
        if($Query->num_rows()>0){
           
           return $Query->row();

        }else{
           
           return false;
        }

	}

	function subscribe($data=array()){
        
        $Query = $this->db->insert('rn_subscribe', $data);
        if($this->db->affected_rows()>0){
            
            return true;       
        }else{
            
            return false;       
        } 
    }

    function contact($data=array()){
        
        $Query = $this->db->insert('rn_contact', $data);
        if($this->db->affected_rows()>0){
            
            return true;       
        }else{
            
            return false;       
        } 
    }    


}