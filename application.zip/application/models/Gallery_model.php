<?php


class Gallery_model extends CI_Model
{
	
	function getImages(){
        
        $Query = $this->db->get('rn_gallery');
        if($Query->num_rows()>0){
           
           return $Query->result();

        }else{
           
           return false;
        }
	}
}